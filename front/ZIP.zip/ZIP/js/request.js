function Showdata(){
	document.getElementsByName("sname")[0].value = "didulalakminda450@gmail.com";
	document.getElementsByName("pname")[0].value = "Godiva";
	document.getElementsByName("cate")[0].value = "Chocolate";
	document.getElementsByName("address")[0].value = "Colombo 7";
	document.getElementsByName("quan")[0].value = "100";
	document.getElementsByName("price")[0].value = "40";
	document.getElementsByName("dis")[0].value = "2";
	document.getElementsByName("edate")[0].value = "12/30/2020";
	document.getElementsByName("des")[0].value = "Good Taste";
}